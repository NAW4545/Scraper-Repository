from mysql.connector import MySQLConnection, Error
from pymysql_dbconfig import read_db_config


def insert_depts(dept_list):
    
    query = "INSERT INTO departments(dept_name) " \
            "VALUES(%s)"
    depts = [list([item]) for item in dept_list]

    try:
        print("Connecting to database...")

        # creates connection to db from pymysql_dbconfig and config.ini
        config = read_db_config()
        conn = MySQLConnection(**config)

        # confirms connection
        if conn.is_connected():
            print("Connection established.")
        else:
            print("Connection failed.")
        
        # creates cursor object and executes/commits db inserts
        cursor = conn.cursor()
        cursor.executemany(query, depts)
        conn.commit()

        print("Insertions made.")

    except Error as error:
        print(error)

    finally:
        cursor.close()
        conn.close()
        print("Connection closed.")



def insert_progs(plist):

    # query to insert data from argument
    query = "INSERT INTO programs(prog_name, dept_id) " \
            "VALUES(%s,%s)"
  
    try:
        print("Connecting to database...")

        # creates connection to db from pymysql_dbconfig and config.ini
        config = read_db_config()
        conn = MySQLConnection(**config)

        # confirms connection
        if conn.is_connected():
            print("Connection established.")
        else:
            print("Connection failed.")

        # creates cursor object and executes/commits db inserts
        cursor = conn.cursor()
        cursor.executemany(query, plist)
        conn.commit()

        print("Insertions made.")

    except Error as error:
        print(error)

    finally:
        cursor.close()
        conn.close()
        print("Connection closed.")



def insert_plos(plo_list):
    
    #query to insert data from argument
    query = "INSERT INTO plos(plo_desc, prog_id) " \
            "VALUES(%s,%s)"
  
    try:
        print("Connecting to database...")

        # creates connection to db from pymysql_dbconfig and config.ini
        config = read_db_config()
        conn = MySQLConnection(**config)

        # confirms connection
        if conn.is_connected():
            print("Connection established.")
        else:
            print("Connection failed.")

        # creates cursor object and executes/commits db inserts
        cursor = conn.cursor()
        cursor.executemany(query, plo_list)
        conn.commit()

        print("Insertions made.")

    except Error as error:
        print(error)

    finally:
        cursor.close()
        conn.close()
        print("Connection closed.")



def insert_courses(course_list):
    
    #query to insert data from argument
    query = "INSERT INTO courses(course_name) " \
            "VALUES(%s)"
    courses = [list([item]) for item in course_list]
  
    try:
        print("Connecting to database...")

        # creates connection to db from pymysql_dbconfig and config.ini
        config = read_db_config()
        conn = MySQLConnection(**config)

        # confirms connection
        if conn.is_connected():
            print("Connection established.")
        else:
            print("Connection failed.")

        # creates cursor object and executes/commits db inserts
        cursor = conn.cursor()
        cursor.executemany(query, courses)
        conn.commit()

        print("Insertions made.")

    except Error as error:
        print(error)

    finally:
        cursor.close()
        conn.close()
        print("Connection closed.")



def insert_slos(slo_list):
    
    #query to insert data from argument
    query = "INSERT INTO course_slos(slo_desc, course_id) " \
            "VALUES(%s,%s)"
  
    try:
        print("Connecting to database...")

        # creates connection to db from pymysql_dbconfig and config.ini
        config = read_db_config()
        conn = MySQLConnection(**config)

        # confirms connection
        if conn.is_connected():
            print("Connection established.")
        else:
            print("Connection failed.")

        # creates cursor object and executes/commits db inserts
        cursor = conn.cursor()
        cursor.executemany(query, slo_list)
        conn.commit()

        print("Insertions made.")

    except Error as error:
        print(error)

    finally:
        cursor.close()
        conn.close()
        print("Connection closed.")



def insert_prog_courses(id_list):

    #query to insert data from argument
    query = "INSERT INTO prog_courses(prog_id, course_id) " \
            "VALUES(%s,%s)"
  
    try:
        print("Connecting to database...")

        # creates connection to db from pymysql_dbconfig and config.ini
        config = read_db_config()
        conn = MySQLConnection(**config)

        # confirms connection
        if conn.is_connected():
            print("Connection established.")
        else:
            print("Connection failed.")

        # creates cursor object and executes/commits db inserts
        cursor = conn.cursor()
        cursor.executemany(query, id_list)
        conn.commit()

        print("Insertions made.")

    except Error as error:
        print(error)

    finally:
        cursor.close()
        conn.close()
        print("Connection closed.")


