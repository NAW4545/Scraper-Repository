import requests
from bs4 import BeautifulSoup as bs
from urllib.parse import urljoin
from plo_db import *


# merges prog names and prog depts into one list of tuples to feed to the db
def merge(list1, list2):

    prog_list = [(list1[i], list2[i]) for i in range(0, len(list1))]

    return prog_list



# scrapes dept names and returns a list
def scrape_depts():

    base_url = "https://programs.butte.edu/ProgramList/All/13/false"
    r = requests.get(base_url)
    soup = bs(r.content, 'html.parser')

    # list to hold dept names
    dept_list = []

    t_body = soup.find("tbody")
            
    prog_rows = t_body.find_all("tr")
    
    # scrapes prog depts and appends each to dept list
    for row in prog_rows:
        dept_list.append(row.contents[5].text)
        
    # removes duplicates and sorts list alphabetically
    dept_list = list(set(dept_list))
    dept_list.sort()
    

    return dept_list



# scrapes progs and returns a list of prog names and dept ids
def scrape_progs(dept_list):

    base_url = "https://programs.butte.edu/ProgramList/All/13/false"
    r = requests.get(base_url)
    soup = bs(r.content, 'html.parser')
    dept_enum_list = list(enumerate(dept_list))

    name_list = []
    id_list = []

    t_body = soup.find("tbody")
    prog_rows = t_body.find_all("tr")
    aTags = t_body.find_all('a')

    # navigates to each prog url and scrapes prog names,
    # then appends each to name list
    for aTag in aTags:
        href = aTag.get('href')
        next_url = urljoin(base_url, href)
        s = requests.get(next_url)
        s_soup = bs(s.content, 'html.parser')

        h5Elements = s_soup.find_all("h5")
        
        for h5 in h5Elements:
            name_list.append(h5.text.strip())

    # matches dept ids to prog names and makes ordered list of dept ids
    for row in prog_rows:
        for id in dept_enum_list:
            if row.contents[5].text == id[1]:
                id_list.append(id[0]+1)

    # merges the two lists into one list of tuples
    prog_list = merge(name_list, id_list)


    return prog_list



# scrapes plos and returns a list of plos and prog ids
def scrape_plos():
    
    base_url = "https://programs.butte.edu/ProgramList/All/13/false"
    r = requests.get(base_url)
    soup = bs(r.content, 'html.parser')

    plo_list = []
    prog_id = 1
    i = 0  # holds current plo_list position

    aTags = []

    # finds all prog links and appends to aTags
    t_body = soup.find("tbody")
    prog_rows = t_body.find_all("th")
    for row in prog_rows:
        aTags.append(row.find("a"))

    for aTag in aTags:
        href = aTag.get('href')
        next_url = urljoin(base_url, href)
        s = requests.get(next_url)
        s_soup = bs(s.content, 'html.parser')

        ul = s_soup.find(class_ = "dots")

        plo = ul.find_all("p")

        # makes new sublist for each plo, appends plo and prog id
        for p in plo:
            plo_list.append([])
            plo_list[i].append(p.text)
            plo_list[i].append(prog_id)
            i += 1
        
        prog_id += 1

        
    return plo_list



# scrapes course names and their associated slos, returns a list for each
def scrape_courses_and_slos():

    # keeps persistent connection during scrape
    with requests.Session() as req:
    
        base_url = "https://www.butte.edu/departments/curriculum/course_outlines/?area="
        headers = {'User-Agent': 'Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148'}
        r = req.get(base_url, headers=headers)
        soup = bs(r.content, 'html.parser')

        course_list = []
        course_iter = 1
        slo_list = []
        slo_iter = 0

        # makes list of url extensions to navigate course catalog
        body = soup.find("body")
        container = body.find(id="leftContent-container")
        links = container.find_all("option")
        links.pop(0)

        # navigates through each "subject" to reach courses and slos
        for link in links:    
            site = link.get("value")
            next_url = base_url + site
            s = requests.get(next_url)
            s_soup = bs(s.content, 'html.parser')

            tbody = s_soup.find("tbody")
            tr = tbody.find_all("tr")

            # makes list of course names and appends to list
            for r in tr:
                td = r.findChildren("td")
                cname = td[1].text
                course_list.append(cname)

            aTags = tbody.find_all("a")
            
            # navigates through each course doc to scrape slos
            for aTag in aTags:

                href = aTag.get("href")
                s = req.get(href, headers=headers)
                s_soup = bs(s.content, "html.parser")

                body = s_soup.find("body")
                ol = body.find("ol")
                slos = ol.find_all("li")

                # makes list of slos and appends to list
                for slo in slos:
                    slo_list.append([])
                    slo_list[slo_iter].append(slo.text)
                    slo_list[slo_iter].append(course_iter)
                    slo_iter += 1

                course_iter += 1
        
        
    return course_list, slo_list



# scrapes course numbers from BC catalog for matching up with prog courses,
# returns a list of course nums and their ids
def scrape_course_nums():

    # keeps persistent connection during scrape
    with requests.Session() as req:
    
        base_url = "https://www.butte.edu/departments/curriculum/course_outlines/?area="
        headers = {'User-Agent': 'Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148'}
        r = req.get(base_url, headers=headers)
        soup = bs(r.content, 'html.parser')

        course_nums = []
        course_iter = 0

        # makes list of url extensions to navigate course catalog
        body = soup.find("body")
        container = body.find(id="leftContent-container")
        links = container.find_all("option")
        links.pop(0)

        # navigates through each "subject" to reach courses and slos
        for link in links:        
            site = link.get("value")
            next_url = base_url + site
            s = requests.get(next_url)
            s_soup = bs(s.content, 'html.parser')

            tbody = s_soup.find("tbody")
            tr = tbody.find_all("tr")

            # makes list of course nums and appends to list
            for r in tr:
                td = r.findChildren("td")
                cnum = td[0].text
                course_nums.append([])
                course_nums[course_iter].append(course_iter+1)
                course_nums[course_iter].append(cnum)    
                course_iter += 1

        
    return course_nums



# scrapes the courses associated with each program, returns a list of the course nums and matching prog ids
def scrape_prog_courses():

    base_url = "https://programs.butte.edu/ProgramList/All/13/false"
    r = requests.get(base_url)
    soup = bs(r.content, 'html.parser')

    # lists to hold prog course numbers and prog ids
    prog_course_list = []

    prog_iter = 0
    course_iter = 0

    aTags = []

    # find all prog links and appends to aTags
    t_body = soup.find("tbody")
    prog_rows = t_body.find_all("th")
    for row in prog_rows:
        aTags.append(row.find("a"))

    # navigates to each prog url and scrapes course numbers, then appends each tolist
    for aTag in aTags:
        href = aTag.get('href')
        next_url = urljoin(base_url, href)
        s = requests.get(next_url)
        s_soup = bs(s.content, 'html.parser')

        div = s_soup.find(id="faqOne")

        a_class = div.find_all(class_="classLinks")

        # finds course numbers and trims excess whitespace and text before appending
        for c in a_class:         
            a_children = c.findChildren("div")
            prog_course_list.append([])
            prog_course_list[course_iter].append(prog_iter+1)
            course_num = a_children[0].text
            course_num = course_num.strip()
            course_num = course_num.replace("\r\n", "")
            course_num = course_num.replace(" ", "-")
            course_num = course_num.replace("or-", "")
            course_num = course_num.replace("and-", "")
            prog_course_list[course_iter].append(course_num)
            course_iter += 1

        prog_iter += 1

    # cuts duplicate courses and sorts list
    cut_dups = list(map(list, set(map(tuple, prog_course_list))))
    cut_dups.sort(key=lambda x: (x[0], x[1]))
    prog_course_list = cut_dups
    
        
    return prog_course_list



# matches prog courses with courses from catalog and returns a list of matched ids
def make_prog_course_list(prog_courses, course_nums):

    prog_course_ids = []
    i = 0  # holds current list position

    # loops through prog_courses and loops through course num list
    # for each prog_course to match id nums, appends matches to list
    for course in prog_courses:
        for c in course_nums:
            if course[1] == c[1]:
                prog_course_ids.append([])
                prog_course_ids[i].append(course[0])
                prog_course_ids[i].append(c[0])
                i += 1
                
    # sorts list
    prog_course_ids.sort(key=lambda x: (x[0], x[1]))
    
    
    return prog_course_ids



def main():
    '''
    # scrapes and inserts departments
    dept_list = scrape_depts()
    insert_depts(dept_list)

    # scrapes and inserts programs
    prog_list = scrape_progs(dept_list)
    insert_progs(prog_list)

    # scrapes and inserts PLOS
    plo_list = scrape_plos()
    insert_plos(plo_list)
    '''
    # scrapes and inserts courses and slos
    course_list, slo_list = scrape_courses_and_slos()
    insert_courses(course_list)
    insert_slos(slo_list)

    # scrapes course numbers from prog courses and course catalog,
    # makes and inserts matched list of ids into prog_courses table
    course_nums = scrape_course_nums()
    prog_courses = scrape_prog_courses()
    prog_course_ids = make_prog_course_list(prog_courses, course_nums)
    insert_prog_courses(prog_course_ids)




if __name__ == '__main__':
    main()

